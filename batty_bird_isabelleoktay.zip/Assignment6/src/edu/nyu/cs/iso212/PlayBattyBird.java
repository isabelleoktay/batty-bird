package edu.nyu.cs.iso212;
import processing.core.*;

/**
 * Basic controller for Batty Bird
 * Instructions: click your mouse to jump! The jumping is annoying to emulate Flappy Bird :)
 * The high score resets every time you restart the app...mine is 21! 
 * @author Isabelle Oktay
 * @version 0.1
 */
public class PlayBattyBird extends PApplet {
	
	// get image path, making sure that it is in the src folder
	private final static String ME_IMAGE_PATH = "picture_of_me.png"; // picture of me
	private final static String BACKGROUND_IMAGE_PATH = "cityscape_background.png"; // background
	
	// will hold images of me and the background
	private PImage meImage;
	private PImage background;
	
	// set window size
	private final int SCREENW = 600;
	private final int SCREENH = 800;
	
	// initialize x and y variables that walls and background will be based on
	private int x = 0, y = this.height/2;
	
	//initialize game mode, score, and high score
	private int gamemode = 0;
	private int score = 0;
	private int highscore = this.score;
	
	// create bat variable in Bat class
	private Bat bat;
	// set bat x coordinate (does not change)
	private final int BAT_X = this.width/2;
	
	// create walls variable in Wall class
	private Wall walls; 
	
	// initalize x and y values of walls made
	private int[] xWalls = {600, 900};
	private int[] yWalls = {this.y, 600};
	
	/**
	 * Automatically called to start your program.  This method calls PApplet's main method and passes it the class name of this class.
	 * @param args Command-line arguments (ignored)
	 */
	public static void main(String[] args) {
		PApplet.main("edu.nyu.cs.iso212.PlayBattyBird");

	}
	
	/**
	 * Called once to set up window
	 */
	public void settings() {
		
		this.size(this.SCREENW, this.SCREENH); // set window size
	}
	
	/**
	 * Called once on load. Used to create the  window and "global" settings.
	 */
	public void setup() {
		
		// set background image and picture of me
		this.meImage = loadImage(ME_IMAGE_PATH);
		this.background = loadImage(BACKGROUND_IMAGE_PATH); 
		
		// initialize bat
		this.bat = new Bat(BAT_X, this.height/2, this);
		 
		// initialize all walls
		for (int i=0; i < 2; i++) {
			this.walls = new Wall(this.xWalls[i], this.yWalls[i], this);
		 }
		 
	}
	
	/**
	 * Called repeatedly approximately 60 times  per second. 
	 * Used to update the animation and  enforce game play logic.
	 */
	public void draw() {
		
		// set image mode in the corner to organize background image
		imageMode(CORNER);
		
		// create 2 background images, one consecutive to the next
		this.image(this.background, this.x, 0);
		this.image(this.background, this.x + this.background.width, 0);
		
		// reset x back to 0 when one of background images moves completely off screen
		// to set up an infinte background loop
		if (this.x < -this.background.width) this.x = 0;
		
		// draw the bat
		this.bat.draw();
		
		// use gamemode 1 as the starting screen
		if (this.getGamemode() == 0) {
			
			// reset all values
			this.setStartingValues();
			
			// resize image of me so it fits properly on screen
			// print image of me
			this.meImage.resize(0, 200);
			this.image(this.meImage, 10, 10);
			
			// print text underneath picture of me
			this.textSize(20);
			this.text("BATTY BIRD by me!\n(Isabelle Oktay)", 
					10, this.meImage.height + 30);
			
			// print text in the middle of the screen
			// click to start game
			this.textSize(20);
			this.text("press your mouse to begin!", 
					this.width/2, this.height/2);
			
			// if you press your mouse, then gamemode moves to 1
			// gamemode 1 is the playing mode
			if (mousePressed) this.setGamemode(1);;
			
		}
		
		// playing mode
		else if (this.getGamemode() == 1) {
			
			// make the bat fall
			this.bat.fall();
			
			// kill bat if bat moves off screen
			if (this.bat.isOffscreen()) {
				this.bat.die();
			}
			
			// iterate through x and y wall values
			// 2 walls per screen
			for (int i = 0; i < 2; i++) {
				
				// set image positioning in the center for ease
				this.imageMode(CENTER);
				
				// set x and y values of wall to the value at i
				this.walls.setX(this.xWalls[i]);
				this.walls.setY(this.yWalls[i]);
				
				// draw the wall
				this.walls.draw();
				
				// move the x value of the wall at i to the left by 4 pixels
				this.xWalls[i] -= 4;
				
				// validate x value of the wall so that is on screen and there is a proper gap
				if (this.getXWall(i) < 0 - this.walls.getWallWidth()/2) {
					this.yWalls[i] = this.walls.getRandomHeight();
					this.xWalls[i] = this.width;
					
				}
				
				// get score if bat passes the wall
				this.getScore(xWalls[i], this.bat);
				
				// move bat offscreen and kill bat if the bat crashes into a lysol can
				if (this.walls.isCrashed(this.bat, i)) {
					this.bat.moveOffscreen();
					this.bat.die();
				}
		
			}
			
			// print the score in the middle on the bottom
			this.text(this.score, this.width/2 - 15, 700);
			
			// move the background 4 pixels to the left to match the movement of the cans
			this.x -= 4;
			
		}
		
		// game over screen
		else if (this.getGamemode() == 2) {
			
			// set text size and print ending message
			this.textSize(20);
			this.text("oh no, you crashed and died trying to avoid\nthe lysol!\n" + 
					"better luck next time :(.\npress the spacebar to play again\n" +
					"score: " + this.score + "\nhighscore: " + this.highscore, 
					this.width/6, this.height/2);
			
			// if a key is pressed
			if (keyPressed) {
				
				// reset bat values
				this.bat.reset();
				
				// reset x value
				this.x = 0;
				
				// go to starting screen
				this.setGamemode(0);
			}
		}
	
	}
	
	/**
	 * Called when mouse is pressed
	 */
	public void mousePressed() {
		// bat jumps
		this.bat.jump();
		
	}
	
	/**
	 * Set gamemode
	 * @param gamemode The gamemode as an int
	 */
	public void setGamemode(int gamemode) {
		this.gamemode = gamemode;
	}
	
	/**
	 * Get gamemode
	 * @return
	 */
	public int getGamemode() {
		return this.gamemode;
	}
	
	/**
	 * Set starting values of the game
	 */
	public void setStartingValues() {
		
		this.xWalls[0] = 600;
		this.yWalls[0] = this.height/2;
		this.xWalls[1] = 900;
		this.yWalls[1] = 600;
		this.x = 0;
		this.score = 0;
	}
	
	/**
	 * Get the xWall value at a specific i position
	 * @param i The xWall value that you want
	 * @return the xWall value
	 */
	public int getXWall(int i) {
		return xWalls[i];
	}
	
	/**
	 * Get the yWall value at a specific i position
	 * @param i The yWall value that you want
	 * @return the yWall value
	 */
	public int getYWall(int i) {
		return yWalls[i];
	}
	
	/**
	 * Get the current score and high score
	 * @param i the xWall value, as an int
	 * @param bat The bat, as a Bat
	 */
	public void getScore(int i, Bat bat) {
		if (i == bat.getX() + bat.getBatWidth()/2 ) {
			this.score ++; // increase when bat passes through a wall
			this.highscore = max(this.score, this.highscore); // store highest score
		}
	}

}
