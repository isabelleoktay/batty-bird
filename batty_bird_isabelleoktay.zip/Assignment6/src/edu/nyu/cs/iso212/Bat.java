package edu.nyu.cs.iso212;
import processing.core.*;

/**
 * The bat class
 * @author Isabelle Oktay
 * @version 0.1
 */
public class Bat {

	//will hold a reference to the PlayBattyBird object, which inherits from PApplet
	// and therefore handles all the Processing-specific stuff
	private PlayBattyBird app;
	
	//make sure the image file is in the src folder
	private final static String BAT_IMAGE_PATH = "bat_character.png"; // bat image file
	private PImage batImage; // will hold bat image
	
	// position and velocity
	private float x, y;
	private float velocity;
	
	// constructor
	public Bat(PApplet app) {
		
		this.app = (PlayBattyBird) app; // keep reference to PApplet class
		this.x = 0;
		this.y = 0;
		this.velocity = 0;
		this.batImage = app.loadImage(Bat.BAT_IMAGE_PATH); // image of bat
		
	}
	
	// second overloaded constructor
	public Bat(int x, int y, PApplet app) {
		
		// set up inital properties for bat
		this.app = (PlayBattyBird) app; // keep reference to PApplet class
		this.x = x; // x value
		this.y = y; // y value
		this.velocity = 0; // velocity value
		this.batImage = app.loadImage(Bat.BAT_IMAGE_PATH); // image of bat
		
	}
	
	// second overloaded constructor
	public Bat(int velocity, int x, int y, PApplet app) {
		
		// set up inital properties for bat
		this.app = (PlayBattyBird) app; // keep reference to PApplet class
		this.x = x; // x value
		this.y = y; // y value
		this.velocity = velocity; // velocity value			
		this.batImage = app.loadImage(Bat.BAT_IMAGE_PATH); // image of bat
			
	}
	
	/**
	 * draw the bat, overrides PApplet drawing
	 */
	public void draw() {
		
		//resize bat image and draw the bat image at current x and y location
		this.batImage.resize(0,35);
		this.app.image(this.batImage, this.x, this.y);
	}
	
	/**
	 * Set y value
	 * @param y the y value, as a float
	 */
	public void setY (float y) {
		this.y = y;
	}
	
	/**
	 * Get the y value
	 * @return the y value, as a float
	 */
	public float getY () {
		return this.y; 
	}
	
	/**
	 * Get the x value
	 * @return the x value, as a float
	 */
	public float getX() {
		return this.x;
	}
	
	/**
	 * Get the width of the bat image
	 * @return the width of the bat image, as an int
	 */
	public int getBatWidth() {
		return this.batImage.width;
	}
	
	/**
	 * Get the height of the bat image
	 * @return the height of the bat image, as an int
	 */
	public int getBatHeight() {
		return this.batImage.height;
	}
	
	/**
	 * Kill the bat
	 */
	public void die() {
		this.app.setGamemode(2); // move to the app gamemode 2 (the ending screen)
	}
	
	/**
	 * make the bat jump
	 */
	public void jump() {
		
		// set velocity to 0 if on the starting screen
		if (this.app.getGamemode() == 0) this.velocity = 0;
		this.velocity -= 12; // velocity is 12
		this.setY(this.getY() - 2); // to simulate gravitational drag
		this.setY(this.getY() + this.velocity); // change y value because velocity changes direction
	}
	
	/**
	 * make bat fall
	 */
	public void fall() {
		this.velocity += .5; 
		this.y += this.velocity; // y compounds velocity every time to simulate gravitational acceleration
		this.setY(this.y);
	}
	
	/**
	 * Check if bat is off screen
	 * @return isOffscreen, whether or not the bat is off screen as a boolean
	 */
	public boolean isOffscreen () {
		float y = this.getY();
		boolean isOffscreen = false;
		
		// if bat is above 0 or length of screen, bat is offscreen
		if (y > this.app.height || y < -this.getBatHeight()) {
			isOffscreen = true;
			this.setY(-this.getHeight()); // if bat is offscreen, move offscreen
		}
		
		return isOffscreen;
	}
	
	/**
	 * get the height of bat image
	 * @return height of bat image as an int
	 */
	public int getHeight() {
		return this.batImage.height;
	}
	
	/**
	 * reset bat values
	 */
	public void reset() {
		this.velocity = -12; // reset initial bat velocity
		this.setY(this.app.height/2); // reset bat height
	}
	
	/**
	 * move bat offscreen
	 */
	public void moveOffscreen() {
		this.setY(-this.getBatHeight());
	}
}
