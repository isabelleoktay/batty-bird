package edu.nyu.cs.iso212;
import processing.core.*;

/**
 * The wall class
 * @author Isabelle Oktay
 * @version 0.1
 */
public class Wall extends PApplet {
	
	//will hold a reference to the PlayBattyBird object, which inherits from PApplet
	// and therefore handles all the Processing-specific stuff
	private PlayBattyBird app;
	
	//make sure the image file is in the src folder
	private final static String WALL_IMAGE_PATH = "lysol_can.png"; // wall image file
	private PImage wallImage; // will hold wall image
	
	// x and y values of wall
	private int x, y;
	
	public Wall (int x, int y, PApplet app) {
		
		// initialize all values
		this.app = (PlayBattyBird) app; // keep reference to PApplet class
		
		this.x = x; // x value
		this.y = y; // y value
		
		this.wallImage = app.loadImage(Wall.WALL_IMAGE_PATH); // image of wall
		
	}
	
	/**
	 * draw wall, overrides PApplet drawing
	 */
	public void draw() {
		// create 2 separate wall images at once
		this.app.image(this.wallImage, this.getX(), this.getY() // top wall
				- (this.getWallHeight()/2 + 100));
		this.app.image(this.wallImage, this.getX(), this.getY() // bottom wall
				+ (this.getWallHeight()/2 + 100));
		
	}
	
	/**
	 * set x value of wall
	 * @param x The x value as an int
	 */
	public void setX(int x) {
		this.x = x;
	}
	
	/**
	 * get x value of the wall
	 * @return the x value as an int
	 */
	public int getX() {
		return this.x;
	}
	
	/**
	 * set y value of the wall
	 * @param y The y value as an int
	 */
	public void setY(int y) {
		this.y = y;
	}
	
	/**
	 * get y value of the wall
	 * @return the y value as an int
	 */
	public int getY() {
		return this.y;
	}
	
	/**
	 * get the width of wall image
	 * @return width as an int
	 */
	public int getWallWidth() {
		return this.wallImage.width;
	}
	
	/**
	 * get the height of wall image
	 * @return height as an int
	 */
	public int getWallHeight()  {
		return this.wallImage.height;
	}
	
	/**
	 * check if bat crashed into a particular wall
	 * @param bat The bat as a Bat
	 * @param i The value of a specific x or y coordinate
	 * @return if the bat crashed as a boolean
	 */
	public boolean isCrashed(Bat bat, int i) {
		
		boolean isCrashed = false; // initalize crash as false
		
		// check top wall
		if (bat.getX() + bat.getBatWidth() >= this.app.getXWall(i) && // left side
			bat.getX() + bat.getBatWidth()/4 <= this.app.getXWall(i) + this.getWallWidth() && // right side
			bat.getY() + bat.getBatHeight() >= 0 && // top
			bat.getY() <= this.app.getYWall(i) - 100) { // bottom
			isCrashed = true;
		}
		
		// check bottom wall
		if (bat.getX() + bat.getBatWidth() >= this.app.getXWall(i) && // left side
			bat.getX() + bat.getBatWidth()/4 <= this.app.getXWall(i) + this.getWallWidth() && // right side
			bat.getY() + bat.getBatHeight() >= this.app.getYWall(i) + 100 && // top
			bat.getY() <= this.app.height) { // bottom
			
			isCrashed = true;
		}
		
		return isCrashed;
	}
	
	/**
	 * get random wall height
	 * @return random height, as an int
	 */
	public int getRandomHeight() {
		int randomHeight = (int) random (200, this.app.height - 200);
		return randomHeight;
	}
	

}

